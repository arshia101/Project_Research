# Run the program

To run the program, NodeJS should be installed on the system.

First, install the required modules by running `npm install` or `npm clean install`.

To run the program run the following command.

```sh 
npm run start
```