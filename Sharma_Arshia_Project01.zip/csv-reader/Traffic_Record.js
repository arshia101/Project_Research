const axios = require("axios");
const fs = require("fs");
const csv = require("csv-parser");

/**
 * 
 */
class TrafficRecord {
  constructor(
    SECTIONID,
    HIGHWAY,
    SECTION,
    SECTIONLENGTH,
    SECTIONDESCRIPTION,
    DATE,
    DESCRIPTION,
    GROUP,
    TYPE,
    COUNTY,
    PTRUCKS,
    ADT,
    DIRECTION
  ) {
    this.SECTIONID = SECTIONID;
    this.HIGHWAY = HIGHWAY;
    this.SECTION = SECTION;
    this.SECTIONLENGTH = SECTIONLENGTH;
    this.SECTIONDESCRIPTION = SECTIONDESCRIPTION;
    this.DATE = DATE;
    this.DESCRIPTION = DESCRIPTION;
    this.GROUP = GROUP;
    this.TYPE = TYPE;
    this.COUNTY = COUNTY;
    this.PTRUCKS = PTRUCKS;
    this.ADT = ADT;
    this.DIRECTION = DIRECTION;
  }

  /**
   * 
   * @param {*} data 
   * @returns 
   */
  static createRecord(data) {
    return new TrafficRecord(
      data["SECTION ID"],
      data.HIGHWAY,
      data.SECTION,
      data["SECTION LENGTH"],
      data["SECTION DESCRIPTION"],
      data["Date"],
      data.DESCRIPTION,
      data.GROUP,
      data.TYPE,
      data.COUNTY,
      data.PTRUCKS,
      data.ADT,
      data.DIRECTION
    );
  }

  /**
   * 
   * @returns Object defining Traffic Record.
   */
  getDetails() {
    return {
      SECTIONID: this.SECTIONID,
      HIGHWAY: this.HIGHWAY,
      SECTION: this.SECTION,
      SECTIONLENGTH: this.SECTIONLENGTH,
      SECTIONDESCRIPTION: this.SECTIONDESCRIPTION,
      date: this.DATE,
      description: this.DESCRIPTION,
      GROUP: this.GROUP,
      TYPE: this.TYPE,
      COUNTY: this.COUNTY,
      PTRUCKS: this.PTRUCKS,
      adt: this.ADT,
      DIRECTION: this.DIRECTION,
    };
  }

  /**
   * 
   * @param {*} updatedData updated data.
   */
  updateRecord(updatedData) {
    for (let prop in updatedData) {
      if (this.hasOwnProperty(prop)) {
        this[prop] = updatedData[prop];
      }
    }
  }

  /**
   * 
   */
  deleteRecord() {
    console.log("Not implemented.");
  }

  /**
   * Output record data.
   */
  outputRecordData() {
    console.log(`Record Data:
    Section ID: ${this.SECTIONID}
    Highway: ${this.HIGHWAY}
    Section: ${this.SECTION}
    Section Length: ${this.SECTIONLENGTH}
    Section Description: ${this.SECTIONDESCRIPTION}
    Date: ${this.DATE}
    Description: ${this.DESCRIPTION}
    Group: ${this.GROUP}
    Type: ${this.TYPE}
    County: ${this.COUNTY}
    Percentage of Trucks: ${this.PTRUCKS}
    Average Daily Traffic: ${this.ADT}
    Direction: ${this.DIRECTION}`);
  }
}

// Display your full name
const fullName = "Arshia Sharma"; // Replace with your full name
console.log(fullName + "!\n"); // Display full name

// /**
// /**
//  * Function to fetch traffic data from an API endpoint
//  * 
//  * @param {*} url of the API endpoint to call.
//  * @param {*} callback to provide the read data to caller.
//  */
// function fetchTrafficDataFromAPI(url, callback) {
//   axios
//     .get(url)
//     .then((response) => {
//       const data = response.data; // Assuming response.data is an array of traffic records
//       const records = data.map((record) => TrafficRecord.createRecord(record));
//       callback(null, records);
//     })
//     .catch((error) => {
//       callback(error, null);
//     });
// }

// // Example usage:
// const apiUrl = "https://api.example.com/traffic-data"; // Replace with the actual API endpoint
// fetchTrafficDataFromAPI(apiUrl, (err, records) => {
//   if (err) {
//     console.error("Error fetching traffic data:", err);
//   } else {
//     console.log("Successfully fetched traffic data:");
//     records.forEach((record, index) => {
//       console.log(`Record ${index + 1}:`);
//       record.outputRecordData();
//     });
//   }
// });

/**
 * Function to read data from CSV file and initialize record objects
 * 
 * @param {*} filename 
 * @param {*} numRecords 
 * @param {*} callback 
 */
function readTrafficDataFromFile(filename, callback) {
  const records = [];
  fs.createReadStream(filename)
    .pipe(csv({separator: ','}))
    .on("data", (row) => {
      const record = TrafficRecord.createRecord(row);
      records.push(record);
    })
    .on("end", () => {
      callback(null, records);
    })
    .on("error", (err) => {
      callback(err, null);
    });
}

// Example usage:
const filename = "Traffic_Volumes__Provincial_Highway_System.csv"; 
readTrafficDataFromFile(filename, (err, records) => {
  if (err) {
    console.error("Error reading file:", err);
  } else {
    console.log("Successfully read records:");
    // Read only first 10 records.
    for (let i = 0; i < 10 && i < records.length; i++){
      records[i].outputRecordData();
      console.log("\n");
    }
  }
});
